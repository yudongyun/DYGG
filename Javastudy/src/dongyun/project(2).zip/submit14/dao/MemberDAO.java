package dongyun.submit14.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dongyun.submit14.vo.MemberVO;

public class MemberDAO {

	
	private MemberDAO() {}
	
	private static MemberDAO instance = new MemberDAO();
	
	public static MemberDAO getInstance() {
		return instance;
	}
	
	// 회원가입하기
	
	public int newMember(Connection conn, String id, String pw, String name) throws SQLException {
		StringBuffer query = new StringBuffer();
		query.append("INSERT INTO members (");
		query.append("		  mem_id		");
		query.append("		, mem_password	");
		query.append("		, mem_name	");
		query.append(") VALUES (			");
		query.append("		  ?				");
		query.append("		, ?				");
		query.append("		, ?				");
		query.append(" 			)			");
		
		PreparedStatement ps = conn.prepareStatement(query.toString());
		
		int idx = 1;
		ps.setString(idx++, id);
		ps.setString(idx++, pw);
		ps.setString(idx++, name);
		
		int cnt = ps.executeUpdate();
		
		ps.close();
		
		return cnt;
	}
	
	// 로그인 메소드
	public MemberVO login(Connection conn, MemberVO mem) throws SQLException {
		StringBuffer query = new StringBuffer();
		query.append("SELECT				");
		query.append("		mem_id			");
		query.append("	,   mem_password 		");
		query.append("FROM					");
		query.append("		members		"); 
		query.append("WHERE 1=1				"); 
		query.append(" AND mem_id = ?				"); 
		query.append(" AND mem_password = ?				"); 
		
		PreparedStatement ps = conn.prepareStatement(query.toString());
		
		int idx = 1;
		ps.setString(idx++, mem.getId());
		ps.setString(idx++, mem.getPw());
		
		ResultSet rs = ps.executeQuery();
		
		MemberVO result = new MemberVO();
		
		while(rs.next()) {
			result.setId(rs.getString("mem_id"));
			result.setPw(rs.getString("mem_password"));
		}
		
		rs.close();
		ps.close();
		
		return result;
	}
	
	// 정보 조회하기
	public void showpro(Connection conn, String id) throws SQLException {
	    StringBuffer query = new StringBuffer();
	    query.append("SELECT mem_id, mem_password, mem_name ");
	    query.append("FROM members ");
	    query.append("WHERE mem_id = ?");

	    PreparedStatement ps = conn.prepareStatement(query.toString());
	    ps.setString(1, id);

	    ResultSet rs = ps.executeQuery();

	    while (rs.next()) {
	        System.out.println("아이디 : " + rs.getString("mem_id"));
	        System.out.println("닉네임 : " + rs.getString("mem_name"));
	    }

	    rs.close();
	    ps.close();
	}
	
	
	
	
	
	
	
	
	
	
	
}
